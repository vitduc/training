/**
 * Copyright © Magento, Inc. All rights reserved.
//  * See COPYING.txt for license details.
 */

define([
    'Magento_Checkout/js/view/summary/abstract-total',
    'Magento_Customer/js/customer-data'
], function (viewModel, customerData) {
    'use strict';

    return viewModel.extend({
        defaults: {
            displayArea: 'after_details',
            template: 'Cowell_BasicTraining/summary/item/details/shipping_fee'
        },

        /**
         * @param {Object} quoteItem
         * @return {*|String}
         */
        getValue: function (quoteItem) {
            let data = window.checkoutConfig.quoteItemData;

            let dataAfterFilter = data.filter(function(item) {
                return item.item_id == quoteItem.item_id;
            })
            return dataAfterFilter[0].shipping_fee;
        }
    });
});
