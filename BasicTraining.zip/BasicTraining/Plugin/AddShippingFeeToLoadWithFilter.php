<?php

namespace Cowell\BasicTraining\Plugin;

use Magento\Framework\Data\Collection;

class AddShippingFeeToLoadWithFilter
{
    /**
     * @param Collection $subject
     * @param bool $printQuery
     * @param bool $logQuery
     * @return array
     */
    public function beforeLoadWithFilter(Collection $subject, $printQuery = false, $logQuery = false): array
    {
        $subject->getSelect()->joinleft(
            ['sf'=>'shipping_fee'],
            "main_table.entity_id = sf.sales_order_id",
        );
        return [$printQuery, $logQuery];
    }
}
