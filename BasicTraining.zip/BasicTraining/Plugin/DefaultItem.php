<?php

namespace Cowell\BasicTraining\Plugin;

use Magento\Quote\Model\Quote\Item;

class DefaultItem
{
    public function aroundGetItemData($subject, \Closure $proceed, Item $item)
    {
        $data = $proceed($item);
        $product = $item->getProduct();

        $atts = [
            "shipping_fee" => $product->getData('shipping_fee')
        ];
        return array_merge($data, $atts);
    }
}
