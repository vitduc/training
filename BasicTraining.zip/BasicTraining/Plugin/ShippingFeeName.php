<?php

namespace Cowell\BasicTraining\Plugin;

use Magento\Sales\Block\Adminhtml\Items\Column\DefaultColumn;

class ShippingFeeName
{
    /**
     * @param DefaultColumn $subject
     * @param array $result
     * @return array
     */
    public function afterGetOrderOptions(DefaultColumn $subject, array $result): array
    {
        $option[] = [
            'label' => 'Shipping Fee: ',
            'value' => $subject->getItem()->getData('shipping_fee') != null ? $subject->getItem()->getData('shipping_fee') : 0
        ];
        return array_merge($option, $result);
    }
}
