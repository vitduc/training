<?php

namespace Cowell\BasicTraining\Plugin\Checkout\CustomerData;

use Magento\Quote\Model\Quote\Item;

class Cart
{
    public function aroundGetItemData($subject, \Closure $proceed, Item $item)
    {
        $data = $proceed($item);
        $product = $item->getProduct();

        $atts = [
            "product_weight" => $product->getAttributeText('weight')
        ];
        return array_merge($data, $atts);
    }
}
