<?php

namespace Cowell\BasicTraining\Plugin;

use Magento\Sales\Block\Adminhtml\Order\View\Items;

class SetColumn
{
    /**
     * @param Items $subject
     * @param array $result
     * @return array
     */
    public function afterGetColumns(Items $subject, array $result): array
    {
        $result['shipping_fee'] = 'Shipping Fee';
        return $result;
    }
}
