<?php

namespace Cowell\BasicTraining\Observer;

use Magento\Framework\DataObject\Copy;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Model\Order;
use Cowell\BasicTraining\Model\ResourceModel\Student;

class SaveShippingFee implements ObserverInterface
{

    /**
     * @var Student
     */
    protected $resource;
    protected $objectCopyService;

    /**
     * @param Student $resource
     * @param Copy $objectCopyService
     */
    public function __construct(
        Student $resource,
        Copy    $objectCopyService
    ) {
        $this->objectCopyService = $objectCopyService;
        $this->resource = $resource;
    }

    /**
     * @param Observer $observer
     * @return $this|void
     */
    public function execute(Observer $observer)
    {
        /* @var Order $order */
        $order = $observer->getEvent()->getData('order');
        $connection = $this->resource->getConnection();
        $select = $connection->insert('shipping_fee', [
            'sales_order_id' => $order->getId(),
            'shipping_fee_2' => $order->getShippingFee(),]);
        return $this;
    }
}
