<?php

namespace Cowell\BasicTraining\Observer;

use Magento\Framework\Event\ObserverInterface;

class SetItemCustomAttribute implements ObserverInterface
{
    protected $productFeeShipping;
    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $quoteItem = $observer->getQuoteItem();
        $this->productFeeShipping = $observer->getProduct()->getData('shipping_fee');
        $quoteItem->setShippingFee($this->productFeeShipping);
    }
}
