<?php

namespace Cowell\BasicTraining\Observer;

use Cowell\BasicTraining\Model\ResourceModel\Student;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class SaveProductStudent implements ObserverInterface
{

    /**
     * @var RequestInterface
     */
    protected $_request;

    protected $student;

    /**
     * @param RequestInterface $request
     */
    public function __construct(
        Student          $student,
        RequestInterface $request,
    ) {
        $this->student = $student;
        $this->_request = $request;
    }

    public function execute(Observer $observer)
    {
        $std = $this->_request->getPost();
        $students = $std->getArrayCopy()['links']['related_students'];
        $product_id = $observer->getProduct('entity_id');
        foreach ($students as $item) {
            $data = [
                'product_id' => $product_id,
                'student_id' => $item['id']
            ];
            $this->student->product_student($data);
        }
        return $this;
    }
}
